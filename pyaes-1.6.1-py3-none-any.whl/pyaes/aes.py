"""Minimal pure-Python AES block cipher + CTR mode (pyaes-compatible API)."""


def _build_tables():
    # Generate S-box and inverse S-box
    sbox = [0] * 256
    p = q = 1
    while True:
        # multiply p by 3 in GF(2^8)
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        # divide q by 3
        q ^= q << 1
        q ^= q << 2
        q ^= q << 4
        q &= 0xFF
        if q & 0x80:
            q ^= 0x09
        x = q ^ (q << 1 | q >> 7) & 0xFF ^ (q << 2 | q >> 6) & 0xFF \
            ^ (q << 3 | q >> 5) & 0xFF ^ (q << 4 | q >> 4) & 0xFF
        sbox[p] = (x ^ 0x63) & 0xFF
        if p == 1:
            break
    sbox[0] = 0x63
    inv = [0] * 256
    for i, v in enumerate(sbox):
        inv[v] = i
    return sbox, inv


_SBOX, _INV_SBOX = _build_tables()


def _xtime(a):
    a <<= 1
    if a & 0x100:
        a ^= 0x11B
    return a & 0xFF


def _mul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a = _xtime(a)
        b >>= 1
    return r


_MUL = {n: [_mul(i, n) for i in range(256)] for n in (2, 3, 9, 11, 13, 14)}


class AES(object):
    """AES block cipher. encrypt/decrypt take and return a list of 16 ints."""

    number_of_rounds = {16: 10, 24: 12, 32: 14}

    def __init__(self, key):
        key = list(bytearray(key))
        if len(key) not in self.number_of_rounds:
            raise ValueError('Invalid key size')
        self._nr = self.number_of_rounds[len(key)]
        self._round_keys = self._expand_key(key)

    def _expand_key(self, key):
        nk = len(key) // 4
        nr = self._nr
        w = [key[4 * i:4 * i + 4] for i in range(nk)]
        rcon = 1
        for i in range(nk, 4 * (nr + 1)):
            t = list(w[i - 1])
            if i % nk == 0:
                t = t[1:] + t[:1]
                t = [_SBOX[b] for b in t]
                t[0] ^= rcon
                rcon = _xtime(rcon)
            elif nk > 6 and i % nk == 4:
                t = [_SBOX[b] for b in t]
            w.append([a ^ b for a, b in zip(w[i - nk], t)])
        rks = []
        for r in range(nr + 1):
            rk = []
            for c in range(4):
                rk.extend(w[4 * r + c])
            rks.append(rk)
        return rks

    @staticmethod
    def _check(block):
        block = list(block)
        if len(block) != 16:
            raise ValueError('wrong block length, expected 16')
        return block

    def encrypt(self, plaintext):
        s = self._check(plaintext)
        rk = self._round_keys
        s = [a ^ b for a, b in zip(s, rk[0])]
        for r in range(1, self._nr + 1):
            s = [_SBOX[b] for b in s]
            # shift rows (state is column-major)
            s = [s[0], s[5], s[10], s[15], s[4], s[9], s[14], s[3],
                 s[8], s[13], s[2], s[7], s[12], s[1], s[6], s[11]]
            if r != self._nr:
                m2, m3 = _MUL[2], _MUL[3]
                n = []
                for c in range(0, 16, 4):
                    a0, a1, a2, a3 = s[c:c + 4]
                    n += [m2[a0] ^ m3[a1] ^ a2 ^ a3,
                          a0 ^ m2[a1] ^ m3[a2] ^ a3,
                          a0 ^ a1 ^ m2[a2] ^ m3[a3],
                          m3[a0] ^ a1 ^ a2 ^ m2[a3]]
                s = n
            s = [a ^ b for a, b in zip(s, rk[r])]
        return s

    def decrypt(self, ciphertext):
        s = self._check(ciphertext)
        rk = self._round_keys
        s = [a ^ b for a, b in zip(s, rk[self._nr])]
        for r in range(self._nr - 1, -1, -1):
            # inverse shift rows
            s = [s[0], s[13], s[10], s[7], s[4], s[1], s[14], s[11],
                 s[8], s[5], s[2], s[15], s[12], s[9], s[6], s[3]]
            s = [_INV_SBOX[b] for b in s]
            s = [a ^ b for a, b in zip(s, rk[r])]
            if r != 0:
                m9, m11, m13, m14 = _MUL[9], _MUL[11], _MUL[13], _MUL[14]
                n = []
                for c in range(0, 16, 4):
                    a0, a1, a2, a3 = s[c:c + 4]
                    n += [m14[a0] ^ m11[a1] ^ m13[a2] ^ m9[a3],
                          m9[a0] ^ m14[a1] ^ m11[a2] ^ m13[a3],
                          m13[a0] ^ m9[a1] ^ m14[a2] ^ m11[a3],
                          m11[a0] ^ m13[a1] ^ m9[a2] ^ m14[a3]]
                s = n
        return s


class Counter(object):
    def __init__(self, initial_value=1):
        self._counter = [((initial_value >> i) % 256)
                         for i in range(128 - 8, -1, -8)]

    @property
    def value(self):
        return self._counter

    def increment(self):
        for i in range(len(self._counter) - 1, -1, -1):
            self._counter[i] += 1
            if self._counter[i] < 256:
                break
            self._counter[i] = 0
        else:
            self._counter = [0] * len(self._counter)


class AESModeOfOperationCTR(object):
    def __init__(self, key, counter=None):
        self._aes = AES(key)
        if counter is None:
            counter = Counter()
        self._counter = counter
        self._remaining_counter = []

    def encrypt(self, plaintext):
        data = list(bytearray(plaintext))
        while len(self._remaining_counter) < len(data):
            self._remaining_counter += self._aes.encrypt(self._counter.value)
            self._counter.increment()
        out = bytes(bytearray(p ^ c for p, c in zip(data, self._remaining_counter)))
        self._remaining_counter = self._remaining_counter[len(data):]
        return out

    decrypt = encrypt
